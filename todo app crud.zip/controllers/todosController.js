const Todo = require('../models/todoSchema')

exports.createTodo = async (req, res)=>{
    const body = req.body;
    try {
        await Todo.create(body)
    } catch (error) {
        console.log(error)
    }
    res.json({
        "message":"Record has been saved"
    })
}

exports.getAllTodos = async (req, res)=>{
    try {
        const todos = await Todo.find({})
        res.json({
            "data":todos
        })
    } catch (error) {
        console.log(error)
    }
}

exports.getTodoById = async (req, res)=>{
    try {
        const todo = await Todo.findById(req.params.id)
        res.json({
            "data":todo
        })
    } catch (error) {
        console.log(error)
    }
}

exports.updateTodo = async (req, res)=>{
    try {
        const todo = await Todo.findByIdAndUpdate(req.params.id, req.body)
        res.json({
            "Message":"Record has been updated"
        })
    } catch (error) {
        console.log(error)
    }
}

exports.deleteTodo = async (req, res)=>{
    try {
        const todo = await Todo.findById(req.params.id);
        todo.remove();
        res.json({
            "Message":"Record has been Deleted"
        })
    } catch (error) {
        console.log(error)
    }
}
