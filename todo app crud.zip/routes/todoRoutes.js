const express = require('express')
const router = express.Router()
const {getAllTodos, createTodo, getTodoById, updateTodo, deleteTodo} = require('../controllers/todosController')


router.route('/todo/new').post(createTodo);
router.route('/todos').get(getAllTodos);
router.route('/todo/:id').get(getTodoById);
router.route('/todo/update/:id').put(updateTodo);
router.route('/todo/delete/:id').delete(deleteTodo);


module.exports = router
