const express = require('express')
const app = express()
const PORT = 5000;
const bodyParser = require('body-parser')
const todoRoutes = require('./routes/todoRoutes')
const connectDB = require('./config/db')
const cors = require('cors')
connectDB();

app.use(bodyParser.json())
app.use(cors({
    origin: 'http://localhost:3000',
    optionsSuccessStatus: 200 
  }))

app.use('/api/v1', todoRoutes)

app.listen(PORT, ()=>console.log(`Server running on PORT:${PORT}`))