const express = require('express')
const app = express()
const PORT = 5000;
const bodyParser = require('body-parser')
const todoRoutes = require('./routes/todoRoutes')
const connectDB = require('./config/db')

connectDB();

app.use(bodyParser.json())

app.use('/api/v1', todoRoutes)


app.listen(PORT, ()=>console.log(`Server running on PORT:${PORT}`))