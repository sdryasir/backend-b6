const express = require('express')
const router = express.Router()
const {getAllTodos, createTodo} = require('../controllers/todosController')


router.route('/todo/new').get(createTodo);
router.route('/todos').get(getAllTodos);


module.exports = router
