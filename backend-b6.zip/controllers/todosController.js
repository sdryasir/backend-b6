exports.getAllTodos = (req, res)=>{
    res.send('Get all todos')
}
exports.createTodo = (req, res)=>{
    const body = req.body;
    console.log(body)
    res.send('Get all todos')
}